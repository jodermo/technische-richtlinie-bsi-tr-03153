1. Syntaxfehler beseitigt.
2. Neue Exception definiert (ERROR_INVALID_TIME) und in H-Files integriert.
3. Neue Funktion definiert (GetTimeSyncVariant) und in H-Files integriert.
4. Neue Exception definiert (ERROR_GET_TIME_SYNC_VARIANT_FAILED) und in H-Files integriert.
5. Neuer enum definiert (SyncVariants) und in H-Files integriert.
6. Exception ERROR_NO_TRANSACTION zur Funktion finishTransaction hinzugefügt.