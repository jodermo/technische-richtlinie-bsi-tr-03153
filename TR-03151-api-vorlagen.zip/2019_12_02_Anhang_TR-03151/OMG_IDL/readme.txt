1. Neue Exception definiert (ErrorInvalidTime).
2. Neue Funktion definiert (GetTimeSyncVariant).
3. Neue Exception definiert (ErrorGetTimeSyncVariantFailed).
4. Neuer enum definiert (SyncVariants).
5. Exception ErrorInvalidTime zur Funktion updateTime hinzugefügt.
6. Exception ErrorNoTransaction zur Funktion finishTransaction hinzugefügt.